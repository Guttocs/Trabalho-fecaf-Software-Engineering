from flask import Flask, jsonify, request

app = Flask(__name__)

tasks = []
task_id_counter = 1

@app.route("/tasks", methods=["POST"])
def create_task():
    global task_id_counter
    data = request.json

    if not data or "title" not in data:
        return jsonify({"error": "Título da tarefa é obrigatório"}), 400

    task = {
        "id": task_id_counter,
        "title": data["title"],
        "description": data.get("description", ""),
        "status": "A Fazer",
        "priority": data.get("priority", "Média")
    }

    tasks.append(task)
    task_id_counter += 1
    return jsonify(task), 201

@app.route("/tasks", methods=["GET"])
def get_tasks():
    return jsonify(tasks), 200

@app.route("/tasks/<int:task_id>", methods=["PUT"])
def update_task(task_id):
    data = request.json
    for task in tasks:
        if task["id"] == task_id:
            task["title"] = data.get("title", task["title"])
            task["description"] = data.get("description", task["description"])
            task["status"] = data.get("status", task["status"])
            task["priority"] = data.get("priority", task["priority"])
            return jsonify(task), 200
    return jsonify({"error": "Tarefa não encontrada"}), 404

@app.route("/tasks/<int:task_id>", methods=["DELETE"])
def delete_task(task_id):
    global tasks
    tasks = [task for task in tasks if task["id"] != task_id]
    return jsonify({"message": "Tarefa removida com sucesso"}), 200

if __name__ == "__main__":
    app.run(debug=True)
