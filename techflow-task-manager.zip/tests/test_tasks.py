from app import app

def test_create_task():
    client = app.test_client()
    response = client.post("/tasks", json={"title": "Teste"})
    assert response.status_code == 201
